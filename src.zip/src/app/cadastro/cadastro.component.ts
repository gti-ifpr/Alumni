import { CursoService } from './../services/curso-service.service';
import { Component, ElementRef, OnInit, ViewChildren } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { CadastroService } from '../services/cadastro.service';

interface Curso {
  id: number;
  descricao: string;

}

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})

export class CadastroComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[] = [];
  egress: any = {};
  hide = true;

  form = new FormGroup({
    cpf: new FormControl('', [Validators.required]),
    login: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    ingresso: new FormControl('', [Validators.required]),
    egresso: new FormControl('', [Validators.required]),
    curso: new FormControl('', [Validators.required]),
    senha: new FormControl('', [Validators.required]),
  });


  cursos : Curso[] = [];

  constructor(
    private cursoService: CursoService,
    private cadastroService : CadastroService
  ) {
  }

  ngOnInit(): void {
    this.cursoService.buscarTodos().subscribe((res : any )=> this.cursos = res);
  }

  buscar() {
    this.cadastroService.salvar(this.form.value).subscribe();
  }

  isEmpty() {
    return Object.keys(this.egress).length === 0;
  }
}
