import { NoticiaService } from './../services/noticia.service';
import { LocalStorageService } from '../services/local-storage.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  horario: any;
  name?: string = "";
  date: any;
  login: any;
  noticias: any = [];

  constructor(
    private localStorageService: LocalStorageService,
    private noticiaService: NoticiaService

  ) { }

  ngOnInit(): void {
    this.verificaNome();
    this.verificaHora();
    this.buscarNoticias();
  }

  verificaHora() {
    this.date = new Date();

    if (this.date.getHours() >= 18 && this.date.getHours() < 24) {
      this.horario = " Boa Noite,";
    }

    if (this.date.getHours() >= 12 && this.date.getHours() < 18) {
      this.horario = " Boa Tarde, ";
    }

    if (this.date.getHours() >= 0 && this.date.getHours() < 12) {
      this.horario = " Bom Dia, ";
    }
  }

  verificaNome() {
    const obj = JSON.parse(this.localStorageService.retornar());
    this.name = obj.nome?.split(" ", 1)[0];
  }

  buscarNoticias() {
    this.noticiaService.buscarTodos().subscribe((res: any) => {
      this.noticias = res;
    });
  }
}
