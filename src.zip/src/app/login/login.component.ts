import { Component, ElementRef, OnInit, ViewChildren } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';

import { LoginService } from '../services/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[] = [];
  form = new FormGroup({
    login: new FormControl('', [Validators.required]),
    senha: new FormControl('', [Validators.required])
  });

  hide = true;

  constructor(
    private loginService: LoginService
  ) {
    //this.usuarioService.logout();
  }

  ngOnInit(): void { }

  ngAfterViewInit() { }

  submit() {
    if (this.form.valid) {
      this.loginService.login(this.form.value).subscribe();
    }
  }
}
