/* Defines the User entity */
export interface Egress {
	name? : string;
	username? : string;
	password? : string;
	cpf? : string;
	registrationNumber? : string;
	email? : string;
	active? : string;
  dateActivation? : string;
  entryYear? : string;
  graduationYear? : string;
}
