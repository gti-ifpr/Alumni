import { NoticiaService } from './../services/noticia.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-noticia',
  templateUrl: './noticia.component.html',
  styleUrls: ['./noticia.component.css']
})
export class NoticiaComponent implements OnInit {
  noticia: any;
  id: any;

  constructor(
    private router: Router,
    private noticiaService: NoticiaService
  ) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as {
      id: string,
    };
    if (state) {
      this.id = state.id;
    } else {
      this.router.navigateByUrl('/home');
    }
  }

  ngOnInit(): void {
    this.noticiaService.buscar(this.id).subscribe((res: any) => {
      this.noticia = res;
    });
  }
}
