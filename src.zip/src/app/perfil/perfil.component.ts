import { RelatoService } from './../services/relato.service';
import { LocalStorageService } from '../services/local-storage.service';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogRelatoComponent } from '../shared/dialog-relato/dialog-relato.component';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.component.html',
  styleUrls: ['./perfil.component.css']
})
export class PerfilComponent implements OnInit {
  name?: string = "";
  login?: string = "";
  curso?: string = "";
  escolaridade?: string = "";
  relato?: string = "";
  relatoId?: number = 0;
  relatoAtualizar?: string = "";

  constructor(
    private localStorageService: LocalStorageService,
    private relatoService : RelatoService,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.verificaDados();
  }

  verificaDados() {
    const obj =  JSON.parse(this.localStorageService.retornar());
    this.name = obj.nome;
    this.login = obj.login;
    this.escolaridade = obj.curso.escolaridade.descricao;
    this.curso = obj.curso.descricao;

    this.relatoService.buscar(obj.id).subscribe((res : any ) => {
      this.relato = res.descricao;
      this.relatoId = res.id;

    });

  }

  openDialog(): void {
    const dialogRef = this.dialog.open(DialogRelatoComponent, {
      width: '600px',
      data: {descricao: this.relato},
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result) {
        this.relato = result;
        this.relatoService.atualizar(this.relatoId, this.relato).subscribe();
      }
    });
  }
}
