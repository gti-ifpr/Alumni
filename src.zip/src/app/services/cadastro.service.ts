import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map, tap } from 'rxjs';
import { LocalStorageService } from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class CadastroService {

  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService,
    private router: Router
  ) { }

  salvar(user: any): any {
    return this.http.post('/egresso/criar', {
      login: user.login,
      cpf: user.cpf,
      senha: user.senha,
      email: user.email,
      anoIngresso: user.ingresso,
      anoFormatura: user.egresso,
      curso: {
        id: user.curso
      }
    },
      { responseType: 'text' }
    ).pipe(
      map(response => response),
      tap({
        next: response => {
          this.router.navigate(['login']);
        },
        error: err => {
        }
      })
    );
  }
}
