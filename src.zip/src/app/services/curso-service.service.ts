import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, tap } from 'rxjs';
import { DialogComponent } from '../shared/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root'
})
export class CursoService {

  constructor(
    private http: HttpClient,
    private dialog: MatDialog,
  ) { }

  buscarTodos(): any {
    return this.http.get('/cursos/todos').pipe(
      map(response => response),
      tap({
        error: err => {
          if (err.status == 500 || err.status == 504 || err.status == 404) {
            this.dialog.open(DialogComponent, {
              data: {
                icon: 'info',
                title: 'Ocorreu um erro....',
                data: 'Não foi possível contatar o servidor',
                button: 'Ok'
              }
            });
          }
        }
      })
    );
  }
}
