import { Injectable } from '@angular/core';

const KEY = 'egresso';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {

  retornar() {
    return localStorage.getItem(KEY) ?? '';
  }

  salvar(token: string) {
    localStorage.setItem(KEY, token);
  }

  deletar() {
    localStorage.removeItem(KEY);
  }

  hasEgresso() {
    return !!this.retornar();
  }

}
