import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, tap } from 'rxjs';
import { DialogComponent } from '../shared/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { LocalStorageService } from './local-storage.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService,
    private dialog: MatDialog,
    private router: Router,
  ) { }

  login(user: any): any {
    return this.http.post('egresso/login', {
      login: user.login,
      senha: user.senha
    },
      { responseType: 'text' }
    ).pipe(
      map(response => response),
      tap({
        next: response => {
          this.localStorage.salvar(response);

          this.acessarHome();
        },
        error: err => {
          if (err.status == 401) {
            this.dialog.open(DialogComponent, {
              data: {
                icon: 'info',
                title: 'Ocorreu um erro....',
                data: 'Login ou Senha são inválidos',
                button: 'Ok'
              }
            });
          } else if (err.status == 500 || err.status == 504 || err.status == 404) {
            this.dialog.open(DialogComponent, {
              data: {
                icon: 'info',
                title: 'Ocorreu um erro....',
                data: 'Não foi possível contatar o servidor',
                button: 'Ok'
              }
            });
          }
        }
      })
    );
  }

  acessarHome() {
    this.router.navigate(['home']);
  }
}
