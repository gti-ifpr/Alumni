import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RelatoService {

  constructor(
    private http : HttpClient
  ) { }

  buscar(id: any) {
    return this.http.get('/relatos/' + id).pipe(
      map(response => response),
      tap({
        next: response => {
        },
        error: err => {
        }
      })
    );
  }

  atualizar(id: any, descricao : any) {
    return this.http.post('/relatos/' + id,
      descricao
    ).pipe(
      map(response => response),
      tap({
        next: response => {
        },
        error: err => {
        }
      })
    );
  }

}
