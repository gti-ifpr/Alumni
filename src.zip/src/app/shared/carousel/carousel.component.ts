import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

interface carouselImage {
  id: number;
  titulo: string;
  descricao: string;
  thumbnail: string;
}

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  @Input() noticias: carouselImage[] = [];
  @Input() indicators = true;
  @Input() controls = true;

  constructor(
    private router: Router
  ) { }

  selectedIndex = 0;

  ngOnInit(): void {
  }

  selecionar(index: number): void {
    this.selectedIndex = index;
  }

  selecionarAnterior(): void {
    if (this.selectedIndex === 0) {
      this.selectedIndex = this.noticias.length - 1;

    } else {
      this.selectedIndex--;
    }
  }

  selecionarProximo(): void {
    if (this.selectedIndex === this.noticias.length - 1) {
      this.selectedIndex = 0;

    } else {
      this.selectedIndex++;
    }
  }

  mostrarNoticia(id: any) {
    this.router.navigateByUrl('/noticia/' + id, { state: { id: id } });
  }
}
