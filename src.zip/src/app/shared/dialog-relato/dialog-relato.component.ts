import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface DialogData {
  descricao: string;
}

@Component({
  selector: 'app-dialog-relato',
  templateUrl: './dialog-relato.component.html',
  styleUrls: ['./dialog-relato.component.css']
})

export class DialogRelatoComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<DialogRelatoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) {}

  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
