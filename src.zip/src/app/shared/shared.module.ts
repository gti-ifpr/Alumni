import { NgModule } from '@angular/core';
import { AppMaterialModule } from './app-material/app-material.module';
import { DialogComponent } from './dialog/dialog.component';
import { HeaderComponent } from './header/header.component';
import { DialogRelatoComponent } from './dialog-relato/dialog-relato.component';
import { FormsModule } from '@angular/forms';
import { CarouselComponent } from './carousel/carousel.component';
import { CommonModule } from '@angular/common';
import { DateFormPipe } from './pipes/date-form.pipe';

@NgModule({
  declarations: [
    HeaderComponent,
    DialogComponent,
    DialogRelatoComponent,
    CarouselComponent,
    DateFormPipe

  ],
  imports: [
    AppMaterialModule,
    FormsModule,
    CommonModule
  ],
  exports: [
    AppMaterialModule,
    HeaderComponent,
    DialogComponent,
    DialogRelatoComponent,
    CarouselComponent,
    DateFormPipe
  ]
})
export class SharedModule { }
